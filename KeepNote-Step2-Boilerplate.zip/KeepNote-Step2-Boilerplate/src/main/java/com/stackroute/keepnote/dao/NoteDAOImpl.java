package com.stackroute.keepnote.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.test.context.ContextConfiguration;

import com.stackroute.keepnote.config.ApplicationContextConfig;
import com.stackroute.keepnote.model.Note;

/*
 * This class is implementing the NoteDAO interface. This class has to be annotated with @Repository
 * annotation.
 * @Repository - is an annotation that marks the specific class as a Data Access Object, thus 
 * 				 clarifying it's role.
 * @Transactional - The transactional annotation itself defines the scope of a single database 
 * 					transaction. The database transaction happens inside the scope of a persistence 
 * 					context.  
 * */
@Repository
@Transactional
@ContextConfiguration(classes = { ApplicationContextConfig.class })
public class NoteDAOImpl implements NoteDAO {

	/*
	 * Autowiring should be implemented for the SessionFactory.
	 */
    @Autowired
    private SessionFactory sessionFactory;

	public NoteDAOImpl(SessionFactory sessionFactory) {
	    this.sessionFactory = sessionFactory;
	}

	/*
	 * Save the note in the database(note) table.
	 */

	public boolean saveNote(Note note) {
	    Session session = this.sessionFactory.getCurrentSession();
	    Boolean isSave= true;
	    try{
	        session.persist(note);
	    }
	    catch (Exception e) {
	        isSave = false;
            // TODO: handle exception
        }
       
        
		return isSave;

	}

	/*
	 * Remove the note from the database(note) table.
	 */

	public boolean deleteNote(int noteId) {
	    Boolean isDelete= true;
	    Session session = this.sessionFactory.getCurrentSession();
	    Note note = (Note) session.load(Note.class, new Integer(noteId));
	    try{
            if(null != note){
                session.delete(note);
            }
	    }
	    catch (Exception e) {
	        isDelete= false;
            // TODO: handle exception
        }
        
       
		return isDelete;

	}

	/*
	 * retrieve all existing notes sorted by created Date in descending
	 * order(showing latest note first)
	 */
	@SuppressWarnings("unchecked")
    public List<Note> getAllNotes() {
	    
	    Session session = this.sessionFactory.getCurrentSession();
        List<Note> noteList = session.createQuery("from Note").list();

        return noteList;

	}

	/*
	 * retrieve specific note from the database(note) table
	 */
	public Note getNoteById(int noteId) {
	    
	    Session session = this.sessionFactory.getCurrentSession();     
	    Note note = (Note) session.load(Note.class, new Integer(noteId));
		return note;

	}

	/* Update existing note */

	public boolean UpdateNote(Note note) {
	    Boolean isUpdate= true;
	    Session session = this.sessionFactory.getCurrentSession();
	    try{
	        session.update(note);
	    }
	    catch (Exception e) {
	        isUpdate = false;
            // TODO: handle exception
        }
        
		return isUpdate;

	}

}
